package Reto3_G5.Reto3_G5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3G5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
